#!/bin/sh

/Applications/Doxygen.app/Contents/Resources/doxygen dox.template && open ./html/index.html
